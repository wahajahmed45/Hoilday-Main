package org.helmo.HolyD.domains.models;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}