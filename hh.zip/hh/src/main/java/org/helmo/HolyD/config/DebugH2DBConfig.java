package org.helmo.HolyD.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

//@Configuration
public class DebugH2DBConfig {

   /* //@Bean
    @Profile("h2Debug")
    public void debugH2DB() {
        org.h2.engine.Mode mode = org.h2.engine.Mode.getInstance("ORACLE");
        mode.limit = true;
    }*/
}
